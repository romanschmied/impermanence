(* Wolfram Language Init File *)

Get[ "Impermanence`Impermanence`"]